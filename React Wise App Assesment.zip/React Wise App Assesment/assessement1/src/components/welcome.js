import React from 'react';

export default function welcome(name){
    return(
        <>

        
        <h1 >Hey ! {name.name1}</h1>

        <h2>Welcome to the LPU College</h2>
        </>
    )
}